let cats = ["Biscuit", "Jungle"];
let dogs = ["Stella", "Camper"];

let animals = [
  "Smoky",
  "Miro",
  "Swimmy",
  ...cats,
  ...dogs
];

console.log(animals);
