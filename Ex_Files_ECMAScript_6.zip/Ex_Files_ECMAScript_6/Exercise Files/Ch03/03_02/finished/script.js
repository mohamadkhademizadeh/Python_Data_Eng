let [first, , , , fifth] = [
  "Spokane",
  "Boston",
  "Los Angeles",
  "Seattle",
  "Portland"
];

console.log(first);
console.log(fifth);
