let cities = [
  "Spokane",
  "Boston",
  "Los Angeles",
  "Seattle",
  "Portland"
];

console.log(cities.includes("Boston"));
console.log(cities.includes("Santa Barbara"));
