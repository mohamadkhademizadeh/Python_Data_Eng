const daytime = {
  breakfast: "oatmeal",
  lunch: "peanut butter and jelly"
};

const nighttime = "mac and cheese";

const backpackingMeals = {
  ...daytime,
  nighttime
};

console.log(backpackingMeals);
