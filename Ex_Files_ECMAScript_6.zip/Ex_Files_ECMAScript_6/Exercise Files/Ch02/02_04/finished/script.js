const planet = "Earth";
console.log(planet.search("h"));
