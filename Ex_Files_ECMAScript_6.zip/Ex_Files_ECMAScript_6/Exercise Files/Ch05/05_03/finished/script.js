// =>

let studentList = (students) =>
  console.log(students);

studentList(["A", "B", "C"]);

let list = ["apple", "banana", "strawberry"];
list.map((item) => console.log(item));
